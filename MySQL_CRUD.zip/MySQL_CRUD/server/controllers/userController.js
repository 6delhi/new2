const db = require("../config/db");

// CREATE
exports.createUser = (req, res) => {
  const { name, age, phone } = req.body;
  const sql = "INSERT INTO users (name, age, phone) VALUES (?, ?, ?)";
  db.query(sql, [name, age, phone], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ id: result.insertId });
  });
};

// READ
exports.getUsers = (req, res) => {
  db.query("SELECT * FROM users", (err, rows) => {
    if (err) return res.status(500).send(err);
    res.send(rows);
  });
};

// UPDATE
exports.updateUser = (req, res) => {
  const { name, age, phone } = req.body;
  const sql = "UPDATE users SET name = ?, age = ?, phone = ? WHERE id = ?";
  db.query(sql, [name, age, phone, req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ updated: result.affectedRows });
  });
};

// DELETE
exports.deleteUser = (req, res) => {
  db.query("DELETE FROM users WHERE id = ?", [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ deleted: result.affectedRows });
  });
};
