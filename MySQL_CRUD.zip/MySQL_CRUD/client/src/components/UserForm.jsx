// import { useState, useEffect } from "react";
import axios from "axios";

const UserForm = ({ editingId, setEditingId, fetchUsers, form, setForm }) => {
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingId) {
      await axios.put(`http://localhost:5000/users/${editingId}`, form);
    } else {
      await axios.post("http://localhost:5000/users", form);
    }
    setForm({ name: "", age: "", phone: "" });
    setEditingId(null);
    fetchUsers();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Name"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <input
        placeholder="Age"
        value={form.age}
        onChange={(e) => setForm({ ...form, age: e.target.value })}
      />
      <input
        placeholder="Phone"
        value={form.phone}
        onChange={(e) => setForm({ ...form, phone: e.target.value })}
      />
      <button type="submit">{editingId ? "Update" : "Add"}</button>
    </form>
  );
};

export default UserForm;
