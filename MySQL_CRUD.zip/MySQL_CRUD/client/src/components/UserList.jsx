const UserList = ({ users, handleEdit, handleDelete }) => {
  return (
    <ul>
      {users.map((user) => (
        <li key={user.id}>
          {user.name}, {user.age}, {user.phone}
          <button onClick={() => handleEdit(user)}>Edit</button>
          <button onClick={() => handleDelete(user.id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
};

export default UserList;
