-- Create Database
CREATE DATABASE IF NOT EXISTS crud_app;
USE crud_app;

-- Create Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    phone VARCHAR(15) NOT NULL
);

-- Insert Sample Data
INSERT INTO users (name, age, phone) VALUES 
('Alice Johnson', 24, '9876543210'),
('Bob Smith', 30, '9123456789'),
('Charlie Brown', 27, '9012345678'),
('Daisy Thomas', 22, '9345678901');
