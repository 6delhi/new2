const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());

// ✅ Connect to MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',         // change if needed
  password: 'cdacacts',         // use your MySQL root password
  database: 'crud_app',
});

// Test connection
db.connect((err) => {
  if (err) throw err;
  console.log('✅ Connected to MySQL');
});

// 🚀 CRUD ROUTES

// CREATE
app.post('/users', (req, res) => {
  const { name, age, phone, email} = req.body;
  const sql = 'INSERT INTO users (name, age, phone, email) VALUES (?, ?, ?, ?)';
  db.query(sql, [name, age, phone, email], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ id: result.insertId });
  });
});

// READ
app.get('/users', (req, res) => {
  db.query('SELECT * FROM users', (err, rows) => {
    if (err) return res.status(500).send(err);
    res.send(rows);
  });
});

// UPDATE
app.put('/users/:id', (req, res) => {
  const { name, age, phone, email } = req.body;
  const sql = 'UPDATE users SET name = ?, age = ?, phone = ?, email = ? WHERE id = ?';
  db.query(sql, [name, age, phone, email, req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ updated: result.affectedRows });
  });
});

// DELETE
app.delete('/users/:id', (req, res) => {
  db.query('DELETE FROM users WHERE id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send({ deleted: result.affectedRows });
  });
});

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
