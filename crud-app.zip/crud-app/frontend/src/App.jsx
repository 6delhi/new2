import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', age: '', phone: '', email: '' });
  const [editingId, setEditingId] = useState(null);

  const fetchUsers = async () => {
    const res = await axios.get('http://localhost:5000/users');
    setUsers(res.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingId) {
      await axios.put(`http://localhost:5000/users/${editingId}`, form);
    } else {
      await axios.post('http://localhost:5000/users', form);
    }
    setForm({ name: '', age: '', phone: '', email: '' });
    setEditingId(null);
    fetchUsers();
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/users/${id}`);
    fetchUsers();
  };

  const handleEdit = (user) => {
    setForm({ name: user.name, age: user.age, phone: user.phone, email: user.email });
    setEditingId(user.id);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Student management</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
        <input placeholder="Age" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} />
        <input placeholder="Phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
        <input  type='email' placeholder="email"  value={form.email} onChange={e => setForm({ ...form, email: e.target.value})}/>
        <button type="submit">{editingId ? 'Update' : 'Add'}</button>
      </form>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {user.name}, {user.age}, {user.phone}, {user.email}
            <button onClick={() => handleEdit(user)}>Edit</button>
            <button onClick={() => handleDelete(user.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
